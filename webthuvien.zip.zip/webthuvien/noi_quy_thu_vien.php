<?php
session_start();
include 'ket_noi.php';
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Nội quy thư viện</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <style>
        body, html {
            margin: 0;
            font-family: Arial, sans-serif;
            height: 100%;
            background-color: #f5f5f5;
        }
        .sidebar {
            width: 240px;
            background-color: #007bff;
            color: white;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            padding: 20px 0;
            overflow-y: auto;
            z-index: 999;
        }
        .sidebar a {
            display: block;
            padding: 12px 20px;
            color: white;
            text-decoration: none;
        }
        .sidebar a:hover {
            background-color: #0056b3;
        }
        .sidebar .sidebar-brand {
            text-align: center;
            margin-bottom: 30px;
        }
        .sidebar .sidebar-icon i {
            font-size: 48px;
        }
        .sidebar .sidebar-brand-text {
            font-size: 30px;
            font-weight: bold;
            line-height: 1.4;
        }

        nav.fixed-top {
            left: 240px;
            width: calc(100% - 240px);
            z-index: 1001;
        }

        .main {
            margin-left: 240px;
            padding: 20px;
            padding-top: 80px;
            flex: 1;
        }

        h2.title {
            font-weight: bold;
            text-align: center;
            margin-bottom: 30px;
            color: #007bff;
        }

        .footer {
            background: #f9f9f9;
            text-align: center;
            padding: 10px 0;
            font-size: 13px;
            color: #555;
            margin-left: 240px;
            width: calc(100% - 240px);
            box-shadow: 0 -1px 3px rgba(0, 0, 0, 0.05);
        }

        .wrapper {
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        
        .noi-quy-card {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            padding: 25px;
        }
        
        .noi-quy-item {
            margin-bottom: 15px;
            padding-bottom: 15px;
            border-bottom: 1px solid #eee;
        }
        
        .noi-quy-item:last-child {
            border-bottom: none;
        }
        
        .section-title {
            color: #007bff;
            font-weight: bold;
            margin-bottom: 15px;
            font-size: 20px;
        }
    </style>
</head>
<body>

<nav class="navbar navbar-light bg-white shadow-sm px-4 py-2 d-flex justify-content-end align-items-center fixed-top">
    <div class="dropdown">
        <?php if (isset($_SESSION['ban_doc'])): ?>
            <a class="dropdown-toggle text-dark text-decoration-none" href="#" id="accountDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                <?php if (isset($_SESSION['ban_doc']['vai_tro']) && $_SESSION['ban_doc']['vai_tro'] === 'admin'): ?>
                    Xin chào, <strong>Admin</strong>
                <?php else: ?>
                    Xin chào, <strong><?= $_SESSION['ban_doc']['ten_dang_nhap'] ?></strong>
                <?php endif; ?>
            </a>
            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="accountDropdown">
                <li><a class="dropdown-item" href="thong_tin_ca_nhan.php">👤 Thông tin cá nhân</a></li>
                <li><a class="dropdown-item" href="sua_thong_tin.php">🛠️ Sửa thông tin</a></li>
                <li><a class="dropdown-item" href="lich_su.php">📖 Lịch sử mượn</a></li>
                <li><a class="dropdown-item" href="dang_xuat.php">🔓 Đăng xuất</a></li>
            </ul>
        <?php else: ?>
            <a class="dropdown-toggle text-dark text-decoration-none" href="#" id="accountDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                Tài khoản
            </a>
            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="accountDropdown">
                <li><a class="dropdown-item" href="dang_nhap.php">🔐 Đăng nhập</a></li>
                <li><a class="dropdown-item" href="dang_ky.php">📝 Đăng ký</a></li>
            </ul>
        <?php endif; ?>
    </div>
</nav>

<div class="sidebar">
    <!-- Logo và tiêu đề có thể click theo điều kiện -->
    <a href="<?php echo isset($_SESSION['ban_doc']) ? 'trang_chu_ban_doc.php' : 'trang_chu.php'; ?>" 
       class="sidebar-brand d-flex align-items-center justify-content-center flex-column mt-3 mb-4 text-white text-decoration-none">
        <div class="sidebar-icon">
            <i class="fas fa-book-reader fa-3x text-white"></i>
        </div>
        <div class="sidebar-brand-text font-weight-bold mt-2 text-center" style="line-height: 1.4; font-size: 30px;">
            QUẢN LÝ<br>THƯ VIỆN
        </div>
    </a>

    <!-- Mục Trang chủ có điều kiện -->
    <a href="<?php echo isset($_SESSION['ban_doc']) ? 'trang_chu_ban_doc.php' : 'trang_chu.php'; ?>">🏠 Trang chủ</a>

    <!-- Các mục còn lại cố định -->
    <a href="gioi_thieu.php">ℹ️ Giới thiệu</a>
    <a href="lien_he.php">📞 Liên hệ</a>
    <?php if (isset($_SESSION['ban_doc'])): ?>
        <a href="dat_phong.php">🏢 Đặt phòng</a>
        <a href="noi_quy_thu_vien.php" class="active">📋 Nội quy thư viện</a>
        <a href="dang_xuat.php">🔓 Đăng xuất</a>
    <?php else: ?>
        <a href="noi_quy_thu_vien.php" class="active">📋 Nội quy thư viện</a>
        <a href="dang_nhap.php">🔐 Đăng nhập</a>
    <?php endif; ?>
</div>


<!-- Nội dung chính -->
<div class="wrapper">
    <div class="main">
        <h2 class="title">📋 NỘI QUY THƯ VIỆN</h2>

        <div class="noi-quy-card">
            <div class="text-center mb-4">
                <img src="images/logo_thu_vien.png" alt="Logo thư viện" style="max-width: 130px; margin-bottom: 15px;">
                <h3 class="text-primary">THƯ VIỆN TRƯỜNG ĐẠI HỌC KINH TẾ KỸ THUẬT CÔNG NGHIỆP </h3>
                <p class="text-muted">Nơi nuôi dưỡng tri thức và phát triển kỹ năng</p>
            </div>

            <div class="noi-quy-content">
                <div class="noi-quy-item">
                    <h4 class="section-title">I. QUY ĐỊNH CHUNG</h4>
                    <ol>
                        <li>Bạn đọc phải xuất trình thẻ thư viện khi vào thư viện và khi mượn tài liệu.</li>
                        <li>Không được sử dụng thẻ của người khác hoặc cho người khác mượn thẻ.</li>
                        <li>Giữ gìn trật tự, vệ sinh trong khu vực thư viện.</li>
                        <li>Không hút thuốc, không mang thức ăn, đồ uống vào thư viện.</li>
                        <li>Tắt chuông điện thoại, nói chuyện nhỏ để không làm ảnh hưởng đến người khác.</li>
                        <li>Tuân thủ hướng dẫn của cán bộ thư viện.</li>
                        <li>Quần áo gọn gàng, lịch sự khi vào thư viện.</li>
                    </ol>
                </div>

                <div class="noi-quy-item">
                    <h4 class="section-title">II. QUY ĐỊNH VỀ MƯỢN TRẢ TÀI LIỆU</h4>
                    <ol>
                        <li>Mỗi bạn đọc được mượn tối đa 5 cuốn sách trong thời hạn 7 ngày.</li>
                        <li>Có thể gia hạn thêm 1 lần với thời gian tối đa 7 ngày nếu tài liệu không có người đặt.</li>
                        <li>Bạn đọc phải kiểm tra tài liệu trước khi mượn, nếu phát hiện hư hỏng phải báo ngay.</li>
                        <li>Không được tự ý mang tài liệu ra khỏi thư viện khi chưa làm thủ tục mượn.</li>
                        <li>Trả tài liệu đúng hạn, trong tình trạng nguyên vẹn như khi mượn.</li>
                        <li>Bạn đọc phải bồi thường nếu làm mất hoặc hư hỏng tài liệu.</li>
                        <li>Phí phạt quá hạn: 5.000 VNĐ/ngày/cuốn sách.</li>
                    </ol>
                </div>

                <div class="noi-quy-item">
                    <h4 class="section-title">III. QUY ĐỊNH VỀ ĐẶT PHÒNG</h4>
                    <ol>
                        <li>Bạn đọc có thể đặt phòng học nhóm với các quy mô từ nhỏ đến lớn.</li>
                        <li>Thời gian đặt phòng tối đa là 2 giờ/lần.</li>
                        <li>Đặt phòng trước ít nhất 24 giờ và không quá 7 ngày.</li>
                        <li>Trả phòng đúng giờ, trong tình trạng sạch sẽ, ngăn nắp.</li>
                        <li>Không được tự ý di chuyển trang thiết bị trong phòng.</li>
                        <li>Báo cáo ngay khi phát hiện hư hỏng hoặc mất mát.</li>
                        <li>Hủy đặt phòng ít nhất 4 giờ trước giờ sử dụng.</li>
                    </ol>
                </div>

                <div class="noi-quy-item">
                    <h4 class="section-title">IV. XỬ LÝ VI PHẠM</h4>
                    <ol>
                        <li>Vi phạm lần 1: Nhắc nhở.</li>
                        <li>Vi phạm lần 2: Cảnh cáo, ghi nhận vào hồ sơ.</li>
                        <li>Vi phạm lần 3: Tạm ngừng quyền sử dụng thư viện trong 1 tháng.</li>
                        <li>Vi phạm nghiêm trọng: Đình chỉ quyền sử dụng thư viện vĩnh viễn.</li>
                        <li>Bồi thường thiệt hại theo quy định cụ thể.</li>
                    </ol>
                </div>
            </div>

            <div class="text-center mt-4">
                <p class="fw-bold">Trân trọng cảm ơn quý bạn đọc đã tuân thủ nội quy!</p>
                <p><em>Ban Giám đốc Thư viện</em></p>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="footer">
        <strong>© 2025 Bản quyền thuộc về Nhóm 1 - DHMT16A1HN</strong>
    </footer>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>