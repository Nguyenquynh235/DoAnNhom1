<style>
    .footer {
    background: #f9f9f9;
    text-align: center;
    padding: 10px 0;
    font-size: 13px;
    color: #555;
    position: fixed;
    bottom: 0;
    left: 240px;
    width: calc(100% - 240px);
    box-shadow: 0 -1px 3px rgba(0, 0, 0, 0.05);
}

</style>

<footer class="footer">
    <strong>© 2025 Bản quyền thuộc về Nhóm 1 - DHMT16A1HN</strong>
</footer>