<?php
session_start();
include 'ket_noi.php';

date_default_timezone_set('Asia/Ho_Chi_Minh');
$ds_kho = $conn->query("SELECT * FROM kho ORDER BY ma_kho DESC");
?>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <title>Quản lý kho</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
  <style>
    body { margin: 0; font-family: Arial; background-color: #f5f5f5; }
    .sidebar { width: 240px; background-color: #007bff; color: white; position: fixed; height: 100vh; overflow-y: auto; }
    .sidebar a { display: block; padding: 12px 20px; color: white; text-decoration: none; }
    .sidebar a:hover, .sidebar .active { background-color: #0056b3; }
    .sidebar .sidebar-brand { text-align: center; padding: 20px 10px; border-bottom: 1px solid rgba(255,255,255,0.2); }
    .main { margin-left: 240px; padding: 20px; padding-top: 80px; }
    nav.fixed-top { left: 240px; width: calc(100% - 240px); background-color: white; }
  </style>
</head>
<body>
<nav class="navbar navbar-light bg-white shadow-sm fixed-top px-4 py-2">
  <span class="fw-bold">🏢 QUẢN LÝ KHO</span>
</nav>
<div class="sidebar">
  <div class="sidebar-brand">
    <i class="fas fa-book-reader fa-3x"></i>
    <div class="sidebar-brand-text">QUẢN LÝ THƯ VIỆN</div>
  </div>
  <a href="trang_chu_admin.php">🏠 Trang chủ</a>
  <a href="quan_ly_sach.php">📚 Quản lý sách</a>
  <a href="quan_ly_ban_doc.php">👥 Quản lý bạn đọc</a>
  <a href="quan_ly_the.php">🪪 Quản lý thẻ</a>
  <div class="sidebar-section active">⚙️ Quản lý hệ thống</div>
  <a href="quan_ly_tai_khoan.php">👤 Quản lý tài khoản</a>
  <a href="quan_ly_kho.php" class="active">🏢 Quản lý kho</a>
  <a href="dang_xuat.php">🔓 Đăng xuất</a>
</div>
<div class="main">
  <div class="container">
    <h4 class="mb-4">Danh sách kho sách</h4>
    <table class="table table-bordered table-hover bg-white">
      <thead class="table-light">
        <tr>
          <th>#</th>
          <th>Tên kho</th>
          <th>Vị trí</th>
        </tr>
      </thead>
      <tbody>
        <?php $i = 1; while ($row = $ds_kho->fetch_assoc()) { ?>
        <tr>
          <td><?= $i++ ?></td>
          <td><?= $row['ten_kho'] ?></td>
          <td><?= $row['vi_tri'] ?></td>
        </tr>
        <?php } ?>
      </tbody>
    </table>
  </div>
</div>
</body>
</html>
