-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 18, 2025 at 06:54 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `qlthuvien`
--

-- --------------------------------------------------------

--
-- Table structure for table `ban_doc`
--

CREATE TABLE `ban_doc` (
  `ma_ban_doc` int(11) NOT NULL,
  `ten_dang_nhap` varchar(50) NOT NULL,
  `mat_khau` varchar(255) NOT NULL,
  `ho_ten` varchar(100) DEFAULT NULL,
  `ngay_sinh` date DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `so_dien_thoai` varchar(20) DEFAULT NULL,
  `dia_chi` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `ban_doc`
--

INSERT INTO `ban_doc` (`ma_ban_doc`, `ten_dang_nhap`, `mat_khau`, `ho_ten`, `ngay_sinh`, `email`, `so_dien_thoai`, `dia_chi`) VALUES
(3, 'phuong1975', '$2y$10$26DQIzD1eRgUXC.McRzIa.zLn1g8VDcwkLqWFVFfuTFo5SCbFMbAC', 'Trịnh Thị Phương', '1975-04-30', 'phg1975@gmail.com', '0365431470', 'Hà Nam'),
(4, 'quynh23', '$2y$10$ccauLe.VhLlRRmiV3m2z8.uqQAN6Sw06PIT7csuOdBZkoQu7MC/wu', 'Nguyễn Thị Quỳnh', '2004-05-23', 'quynh23@gmail.com', '0962030970', 'Hà Nam'),
(5, 'quan17', '$2y$10$XNex3/74ZWH0NrsVRiNdM.0QfLBzOhs9mVTbj2T4n1J4dI8ls0Pci', 'Phạm Mạnh Quân', '2004-12-17', 'quan1712@gmail.com', '0372473780', 'Hải Phòng'),
(6, 'phuong1901', '$2y$10$77Iins7R9sMG1Oqioe1lB.WHCw1vPeschrkifF9JjNEb5c9MAwvnS', 'Nguyễn Thị Phượng', '1997-01-19', 'phuong01@gmail.com', '0394568245', 'Nam Định'),
(7, 'an2000', '$2y$10$Btyo.vcv0tCiPgW0ipXX3.IMdM8Yrhnp4mKwOMREF6ot0V3zaDolG', 'Phạm Minh An', '1999-04-19', 'anne@gmail.com', '0964685125', 'Lào Cai'),
(8, 'anh256', '$2y$10$/4Y3QNElSLjzyzBRbtmzQOIzHeZoAjqxYvKn5e/pXgfwyOifJJnh2', 'Bùi Thanh Anh', '2003-08-06', 'anhth9@gmail.com', '0356547892', 'Bình Dương');

-- --------------------------------------------------------

--
-- Table structure for table `chi_tiet_muon`
--

CREATE TABLE `chi_tiet_muon` (
  `ma_phieu` int(11) NOT NULL,
  `ma_sach` int(11) NOT NULL,
  `so_luong` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `chi_tiet_nhap`
--

CREATE TABLE `chi_tiet_nhap` (
  `ma_phieu_nhap` int(11) NOT NULL,
  `ma_sach` int(11) NOT NULL,
  `so_luong` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `nha_cung_cap`
--

CREATE TABLE `nha_cung_cap` (
  `ma_ncc` int(11) NOT NULL,
  `ten_ncc` varchar(100) DEFAULT NULL,
  `dia_chi` varchar(255) DEFAULT NULL,
  `so_dien_thoai` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `phieu_muon`
--

CREATE TABLE `phieu_muon` (
  `ma_phieu` int(11) NOT NULL,
  `ma_ban_doc` int(11) DEFAULT NULL,
  `ngay_muon` date DEFAULT NULL,
  `ngay_tra` date DEFAULT NULL,
  `trang_thai` enum('dang_muon','da_tra') DEFAULT 'dang_muon'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `phieu_nhap`
--

CREATE TABLE `phieu_nhap` (
  `ma_phieu_nhap` int(11) NOT NULL,
  `ngay_nhap` date DEFAULT NULL,
  `ma_ncc` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `phong`
--

CREATE TABLE `phong` (
  `id` int(11) NOT NULL,
  `ten_phong` varchar(50) DEFAULT NULL,
  `suc_chua` int(11) DEFAULT NULL,
  `loai_nhom` varchar(50) DEFAULT NULL,
  `trang_thai` varchar(20) DEFAULT 'trống',
  `mo_ta` text DEFAULT NULL,
  `anh` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `phong`
--

INSERT INTO `phong` (`id`, `ten_phong`, `suc_chua`, `loai_nhom`, `trang_thai`, `mo_ta`, `anh`) VALUES
(1, 'Phòng Nhỏ 1', 6, 'nhỏ', 'trống', NULL, 'nho1.jpg'),
(2, 'Phòng Nhỏ 2', 6, 'nhỏ', 'trống', NULL, 'nho2.jpg'),
(3, 'Phòng Nhỏ 3', 6, 'nhỏ', 'trống', NULL, 'nho3.jpg'),
(4, 'Phòng Nhỏ 4', 6, 'nhỏ', 'trống', NULL, 'nho4.jpg'),
(5, 'Phòng Nhỏ 5', 6, 'nhỏ', 'trống', NULL, 'nho5.jpg'),
(6, 'Phòng Nhỏ 6', 6, 'nhỏ', 'trống', NULL, 'nho6.jpg'),
(7, 'Phòng Vừa 1', 15, 'vừa', 'trống', NULL, 'vua1.jpg'),
(8, 'Phòng Vừa 2', 16, 'vừa', 'trống', NULL, 'vua2.jpg'),
(9, 'Phòng Vừa 3', 18, 'vừa', 'trống', NULL, 'vua3.jpg'),
(10, 'Phòng Vừa 4', 20, 'vừa', 'trống', NULL, 'vua4.jpg'),
(11, 'Phòng Vừa 5', 14, 'vừa', 'trống', NULL, 'vua5.jpg'),
(12, 'Phòng Vừa 6', 19, 'vừa', 'trống', NULL, 'vua6.jpg'),
(13, 'Phòng Vừa 7', 17, 'vừa', 'trống', NULL, 'vua7.jpg'),
(14, 'Phòng Lớn 1', 30, 'lớn', 'trống', NULL, 'lon1.jpg'),
(15, 'Phòng Lớn 2', 40, 'lớn', 'trống', NULL, 'lon2.jpg'),
(16, 'Phòng Lớn 3', 45, 'lớn', 'trống', NULL, 'lon3.jpg'),
(17, 'Phòng Lớn 4', 50, 'lớn', 'trống', NULL, 'lon4.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `sach`
--

CREATE TABLE `sach` (
  `ma_sach` int(11) NOT NULL,
  `ten_sach` varchar(255) NOT NULL,
  `tac_gia` varchar(255) DEFAULT NULL,
  `nha_xuat_ban` varchar(100) DEFAULT NULL,
  `nam_xuat_ban` int(11) DEFAULT NULL,
  `so_luong` int(11) DEFAULT 1,
  `anh` varchar(255) DEFAULT NULL,
  `the_loai` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sach`
--

INSERT INTO `sach` (`ma_sach`, `ten_sach`, `tac_gia`, `nha_xuat_ban`, `nam_xuat_ban`, `so_luong`, `anh`, `the_loai`) VALUES
(1, 'Khéo ăn nói sẽ có được thiên hạ', 'Trác Nhã', 'NXB Lao Động', 2017, 21, 'sach1.jpg', 'Kỹ năng giao tiếp'),
(2, '500 bài thuốc hay chữa bệnh theo kinh nghiệm dân gian', 'Nhiều tác giả', 'NXB Y học', 2015, 6, 'sach2.jpg', 'Y học'),
(3, 'Lén nhặt chuyện đời', 'Mộc Trầm', 'NXB Văn Học', 2012, 7, 'sach3.jpg', 'Tiểu thuyết ngôn tình'),
(4, 'Điện toán đám mây', 'Nhiều tác giả', 'NXB Bách Khoa Hà Nội', 2018, 10, 'sach4.jpg', 'Công nghệ thông tin'),
(5, 'Cấu trúc dữ liệu và thuật toán', 'Nguyễn Đức Nghĩa', 'NXB Bách Khoa Hà Nội', 2016, 3, 'sach5.jpg', 'Tin học '),
(6, 'Nhập môn Linux & phần mềm mã nguồn mở', 'Hà Quốc Trung', 'NXB Bách Khoa Hà Nội', 2014, 8, 'sach6.jpg', 'Tin học '),
(7, 'Contemporary Linguistics', 'William O\'Grady', 'Bedford/St. Martin\'s', 2010, 6, 'sach7.jpg', 'Ngôn ngữ học'),
(8, 'An Introduction to Language and Linguistics', 'Ralph Fasold & Jeff Connor-Linton', 'Cambridge University Press', 2006, 23, 'sach8.jpg', 'Ngôn ngữ học'),
(9, 'Kế toán quản trị', 'PGS.TS. Nguyễn Ngọc Quang', 'NXB Đại học Kinh tế quốc dân', 2013, 13, 'sach9.jpg', 'Kế toán'),
(10, 'Luật kế toán – Chế độ kế toán dành cho doanh nghiệp', 'Kim Phượng', 'NXB Tài chính', 2015, 22, 'sach10.jpg', 'Kế toán'),
(11, 'Kế toán thương mại dịch vụ', 'TS. Trần Phước', 'NXB Tài Chính', 2014, 4, 'sach11.jpg', 'Kế toán'),
(12, 'Chí Phèo', 'Nam Cao', 'NXB Văn Học', 1941, 30, 'sach12.jpg', 'Văn học'),
(13, 'Số đỏ', 'Vũ Trọng Phụng', 'NXB Văn Học', 1936, 11, 'sach13.jpg', 'Văn học '),
(14, 'Truyện Kiều', 'Nguyễn Du', 'NXB Văn Học', 1820, 9, 'sach14.jpg', 'Văn học'),
(15, 'Cánh đồng bất tận', 'Nguyễn Ngọc Tư', 'NXB Trẻ', 2005, 2, 'sach15.jpg', 'Văn học'),
(16, 'Tâm lý học ứng dụng', 'Patrick King', 'NXB Giáo dục Việt Nam', 2012, 1, 'sach16.jpg', 'Tâm lý học'),
(17, 'Tâm lý học tội phạm', 'Stantion E. Samenow', 'NXB Công an nhân dân', 2013, 11, 'sach17.jpg', 'Tâm lý học '),
(18, 'Tâm lý phát triển của học sinh', 'Nguyễn Sinh-Lan Phương', 'NXB Lao Động', 2011, 15, 'sach18.jpg', 'Tâm lý học'),
(19, 'Luật bảo vệ môi trường', 'Quốc hội Việt Nam', 'NXB Chính trị quốc gia', 2014, 25, 'sach19.jpg', 'Pháp luật'),
(20, 'Luật trật tự, an toàn giao thông đường bộ', 'Bộ GTVT', 'NXB Giao thông vận tải', 2015, 17, 'sach20.jpg', 'Pháp luật'),
(21, 'Công tác phòng chống dịch bệnh trong nhà trường', 'Bộ Y tế', 'NXB Giáo dục Việt Nam', 2016, 6, 'sach21.jpg', 'Y học'),
(22, 'Tuyển tập các bản án – Hình sự', 'TAND Tối cao', 'NXB Tư pháp', 2017, 7, 'sach22.jpg', 'Pháp luật '),
(23, 'Tuyển tập các bản án – Dân sự', 'TAND Tối cao', 'NXB Tư pháp', 2017, 18, 'sach23.jpg', 'Pháp luật'),
(24, 'Các thông tư liên tịch', 'Nhiều tác giả', 'NXB Tư pháp', 2018, 13, 'sach24.jpg', 'Pháp luật'),
(25, 'Tuyển tập 63 án lệ', 'TAND Tối cao', 'NXB Tư pháp', 2016, 19, 'sach25.jpg', 'Pháp luật'),
(26, 'Một số vấn đề về tín ngưỡng tôn giáo ở Việt Nam', 'Ban Tôn giáo Chính phủ', 'NXB Tôn giáo', 2015, 4, 'sach26.jpg', 'Tôn giáo'),
(27, 'Phật tích', 'Thích Minh Châu', 'NXB Tôn giáo', 2010, 8, 'sach27.jpg', 'Tôn giáo'),
(28, 'Thời đại Hùng Vương', 'Nhiều tác giả', 'NXB Khoa học xã hội', 2013, 13, 'sach28.jpg', 'Văn hóa'),
(29, 'Sách thánh hiền nhân', 'Nhiều tác giả', 'NXB Văn Hóa', 2012, 10, 'sach29.jpg', 'Văn hóa'),
(30, 'Sửa ta so với sử tàu', 'Nhiều tác giả', 'NXB Giáo dục Việt Nam', 2014, 8, 'sach30.jpg', 'Văn hóa');

-- --------------------------------------------------------

--
-- Table structure for table `vi_pham`
--

CREATE TABLE `vi_pham` (
  `ma_vi_pham` int(11) NOT NULL,
  `ma_phieu` int(11) DEFAULT NULL,
  `noi_dung` text DEFAULT NULL,
  `muc_phat` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ban_doc`
--
ALTER TABLE `ban_doc`
  ADD PRIMARY KEY (`ma_ban_doc`),
  ADD UNIQUE KEY `ten_dang_nhap` (`ten_dang_nhap`);

--
-- Indexes for table `chi_tiet_muon`
--
ALTER TABLE `chi_tiet_muon`
  ADD PRIMARY KEY (`ma_phieu`,`ma_sach`),
  ADD KEY `ma_sach` (`ma_sach`);

--
-- Indexes for table `chi_tiet_nhap`
--
ALTER TABLE `chi_tiet_nhap`
  ADD PRIMARY KEY (`ma_phieu_nhap`,`ma_sach`),
  ADD KEY `ma_sach` (`ma_sach`);

--
-- Indexes for table `nha_cung_cap`
--
ALTER TABLE `nha_cung_cap`
  ADD PRIMARY KEY (`ma_ncc`);

--
-- Indexes for table `phieu_muon`
--
ALTER TABLE `phieu_muon`
  ADD PRIMARY KEY (`ma_phieu`),
  ADD KEY `ma_ban_doc` (`ma_ban_doc`);

--
-- Indexes for table `phieu_nhap`
--
ALTER TABLE `phieu_nhap`
  ADD PRIMARY KEY (`ma_phieu_nhap`),
  ADD KEY `ma_ncc` (`ma_ncc`);

--
-- Indexes for table `phong`
--
ALTER TABLE `phong`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sach`
--
ALTER TABLE `sach`
  ADD PRIMARY KEY (`ma_sach`);

--
-- Indexes for table `vi_pham`
--
ALTER TABLE `vi_pham`
  ADD PRIMARY KEY (`ma_vi_pham`),
  ADD KEY `ma_phieu` (`ma_phieu`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ban_doc`
--
ALTER TABLE `ban_doc`
  MODIFY `ma_ban_doc` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `nha_cung_cap`
--
ALTER TABLE `nha_cung_cap`
  MODIFY `ma_ncc` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `phieu_muon`
--
ALTER TABLE `phieu_muon`
  MODIFY `ma_phieu` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `phieu_nhap`
--
ALTER TABLE `phieu_nhap`
  MODIFY `ma_phieu_nhap` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `phong`
--
ALTER TABLE `phong`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `sach`
--
ALTER TABLE `sach`
  MODIFY `ma_sach` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=92;

--
-- AUTO_INCREMENT for table `vi_pham`
--
ALTER TABLE `vi_pham`
  MODIFY `ma_vi_pham` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `chi_tiet_muon`
--
ALTER TABLE `chi_tiet_muon`
  ADD CONSTRAINT `chi_tiet_muon_ibfk_1` FOREIGN KEY (`ma_phieu`) REFERENCES `phieu_muon` (`ma_phieu`),
  ADD CONSTRAINT `chi_tiet_muon_ibfk_2` FOREIGN KEY (`ma_sach`) REFERENCES `sach` (`ma_sach`);

--
-- Constraints for table `chi_tiet_nhap`
--
ALTER TABLE `chi_tiet_nhap`
  ADD CONSTRAINT `chi_tiet_nhap_ibfk_1` FOREIGN KEY (`ma_phieu_nhap`) REFERENCES `phieu_nhap` (`ma_phieu_nhap`),
  ADD CONSTRAINT `chi_tiet_nhap_ibfk_2` FOREIGN KEY (`ma_sach`) REFERENCES `sach` (`ma_sach`);

--
-- Constraints for table `phieu_muon`
--
ALTER TABLE `phieu_muon`
  ADD CONSTRAINT `phieu_muon_ibfk_1` FOREIGN KEY (`ma_ban_doc`) REFERENCES `ban_doc` (`ma_ban_doc`);

--
-- Constraints for table `phieu_nhap`
--
ALTER TABLE `phieu_nhap`
  ADD CONSTRAINT `phieu_nhap_ibfk_1` FOREIGN KEY (`ma_ncc`) REFERENCES `nha_cung_cap` (`ma_ncc`);

--
-- Constraints for table `vi_pham`
--
ALTER TABLE `vi_pham`
  ADD CONSTRAINT `vi_pham_ibfk_1` FOREIGN KEY (`ma_phieu`) REFERENCES `phieu_muon` (`ma_phieu`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
